import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ProfilePage extends JFrame {
    private String email;
    private String token;

    public ProfilePage(String email, String token) {
        this.email = email;
        this.token = token;
        setTitle("Profile Page");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel emailLabel = new JLabel("Email: " + email);
        emailLabel.setBounds(10, 10, 300, 25);
        add(emailLabel);

        JButton buyProductButton = new JButton("Buy Products");
        buyProductButton.setBounds(10, 50, 150, 25);
        add(buyProductButton);

        buyProductButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ProductPage productPage = new ProductPage(token);
                productPage.setVisible(true);
                dispose();
            }
        });
    }
}
