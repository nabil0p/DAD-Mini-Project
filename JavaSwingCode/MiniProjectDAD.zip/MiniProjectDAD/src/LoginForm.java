import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.json.JSONObject;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.awt.event.ActionEvent;

public class LoginForm extends JFrame {
    private JTextField emailField;
    private JTextField passwordField;

    public LoginForm() {
        setTitle("Customer Login");
        setSize(300, 200); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel titleLabel = new JLabel("WELCOME TO CUSTOM PC SHOP");
        titleLabel.setBounds(10, 10, 280, 25);
        add(titleLabel);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(10, 50, 80, 25); 
        add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(100, 50, 160, 25);
        add(emailField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 80, 80, 25); 
        add(passwordLabel);

        passwordField = new JTextField();
        passwordField.setBounds(100, 80, 160, 25); 
        add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(10, 120, 80, 25); 
        add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loginAction();
            }
        });
    }

    private void loginAction() {
        String email = emailField.getText();
        String password = passwordField.getText();

        try {
            String url = "http://192.168.1.116:8000/api/login";
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost postRequest = new HttpPost(url);
            postRequest.setHeader("Content-Type", "application/json");

            JSONObject json = new JSONObject();
            json.put("email", email);
            json.put("password", password);

            StringEntity entity = new StringEntity(json.toString());
            postRequest.setEntity(entity);

            HttpResponse response = httpClient.execute(postRequest);
            HttpEntity httpEntity = response.getEntity();

            if (httpEntity != null) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(httpEntity.getContent()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }

                JSONObject jsonResponse = new JSONObject(result.toString());

                // Check if the response contains a token
                if (jsonResponse.has("token")) {
                    String token = jsonResponse.getString("token");
                    ProfilePage profilePage = new ProfilePage(email, token);
                    profilePage.setVisible(true);
                } else {
                    // Handle the case where no token is provided
                    ProfilePage profilePage = new ProfilePage(email, null);
                    profilePage.setVisible(true);
                }

                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid email or password", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error connecting to the server", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
