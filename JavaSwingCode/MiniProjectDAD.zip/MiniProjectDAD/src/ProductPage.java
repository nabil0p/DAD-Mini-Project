import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class ProductPage extends JFrame {
    private JTable productTable;
    private DefaultTableModel tableModel;
    private JTextField quantityField;
    private String token;

    public ProductPage(String token) {
        this.token = token;
        setTitle("Product Page");
        setSize(800, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        
        JLabel titleLabel = new JLabel("Custom PC Product");
        titleLabel.setBounds(10, 10, 200, 25);
        add(titleLabel);
        
        String[] columnNames = {"ID", "Product", "Price RM", "Product Code", "Description", "Quantity", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // This causes all cells to be non-editable
                return false;
            }
        };
        productTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(productTable); // Create a JScrollPane
        scrollPane.setBounds(10, 40, 760, 100); // Set the bounds of the JScrollPane
        add(scrollPane); 

        loadProducts();

        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setBounds(10, 150, 80, 25); 
        add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setBounds(100, 150, 160, 25); 
        add(quantityField);

        JButton buyButton = new JButton("Buy");
        buyButton.setBounds(270, 150, 80, 25); 
        add(buyButton);

        buyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buyAction();
            }
        });
    }

    private void loadProducts() {
    	try {
            String url = "http://192.168.1.116:8000/api/products";
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpGet getRequest = new HttpGet(url);

            HttpResponse response = httpClient.execute(getRequest);
            HttpEntity httpEntity = response.getEntity();

            if (httpEntity != null) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(httpEntity.getContent()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }

                JSONArray products;
                try {
                    products = new JSONArray(result.toString());
                } catch (JSONException ex) {
                    JSONObject jsonResponse = new JSONObject(result.toString());
                    products = jsonResponse.getJSONArray("products");
                }

                for (int i = 0; i < products.length(); i++) {
                    JSONObject product = products.getJSONObject(i);
                    int id = product.getInt("id");
                    String title = product.getString("title");
                    double price = product.getDouble("price");
                    String productCode = product.getString("product_code"); // Assuming the product code is available in the response
                    String description = product.getString("description"); // Assuming the description is available in the response
                    int quantity = product.getInt("quantity");
                    String status = product.getString("status"); // Assuming the status is available in the response

                    tableModel.addRow(new Object[]{id, title, price, productCode, description, quantity, status});
                }
            } else {
                JOptionPane.showMessageDialog(this, "Error loading products", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error connecting to the server", "Error", JOptionPane.ERROR_MESSAGE);
        }
 
    }


    private void buyAction() {
        int selectedRow = productTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String quantityText = quantityField.getText();
        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid quantity", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int productId = (int) tableModel.getValueAt(selectedRow, 0);
        double pricePerUnit = (double) tableModel.getValueAt(selectedRow, 2);
        int availableQuantity;
        try {
            availableQuantity = Integer.parseInt(tableModel.getValueAt(selectedRow, 5).toString()); // Changed from 3 to 5
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid quantity in the table", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (quantity > availableQuantity) {
            JOptionPane.showMessageDialog(this, "Insufficient stock", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double totalPrice = pricePerUnit * quantity;
        
        
        try {
            String url = "http://192.168.1.116:8000/api/products/" + productId;
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPut putRequest = new HttpPut(url);

            // No token is required for this request
            // putRequest.setHeader("Authorization", "Bearer " + token);

            putRequest.setHeader("Content-Type", "application/json");

            JSONObject json = new JSONObject();
            json.put("quantity", availableQuantity - quantity);

            StringEntity entity = new StringEntity(json.toString());
            putRequest.setEntity(entity);

            HttpResponse response = httpClient.execute(putRequest);
            HttpEntity httpEntity = response.getEntity();

            if (httpEntity != null) {
                JOptionPane.showMessageDialog(this, "Purchase successful. \n Total price: RM " + totalPrice, "Success", JOptionPane.INFORMATION_MESSAGE);
                
                // Decrease the quantity in the table
                int newQuantity = availableQuantity - quantity;
                tableModel.setValueAt(newQuantity, selectedRow, 5); // Changed from 3 to 5
                // Clear the table
                tableModel.setRowCount(0);
                loadProducts();
            } else {
                JOptionPane.showMessageDialog(this, "Error purchasing product", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error connecting to the server", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
    }

    
}
