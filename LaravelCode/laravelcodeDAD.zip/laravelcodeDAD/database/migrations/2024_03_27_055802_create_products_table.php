<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('quantity')->nullable(); // Add the new quantity column
            $table->string('status')->default('available'); // Add the new status column with a default value
        });

        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('price');
            $table->string('product_code');
            $table->string('description');
            $table->string('quantity');
            $table->string('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
        
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn('quantity'); // Rollback the quantity column
            $table->dropColumn('status'); // Rollback the status column
        });
    }
    
};
