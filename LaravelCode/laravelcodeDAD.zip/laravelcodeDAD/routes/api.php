<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProductController;
 

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
 
Route::get('users', [UserController::class, 'index']);
Route::get('users/{id}', [UserController::class, 'show']); 
Route::post('addnew', [UserController::class, 'store']); 
Route::put('usersupdate/{id}', [UserController::class, 'update']);
Route::delete('usersdelete/{id}', [UserController::class, 'destroy']);


Route::post('register', [UserController::class, 'apiRegister']);
Route::post('login', [UserController::class, 'apiLogin']);


Route::get('products', [ProductController::class, 'apiIndex']);
Route::get('products/{id}', [ProductController::class, 'apiShow']);
Route::put('products/{id}', [ProductController::class, 'apiUpdate']);
Route::post('products/search', [ProductController::class, 'apiSearch']);
Route::get('products/search', [ProductController::class, 'apiSearch']);
