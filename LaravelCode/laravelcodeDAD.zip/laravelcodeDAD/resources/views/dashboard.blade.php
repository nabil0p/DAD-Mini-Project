
@extends('layouts.app')
  
@section('title', 'Welcome Admin :D')
  
@section('contents')
  <div class="row">
    Welcome to Custom PC Shop Admin
  </div>
@endsection